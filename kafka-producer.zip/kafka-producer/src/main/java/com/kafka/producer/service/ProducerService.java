package com.kafka.producer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.kafka.producer.IConstant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class ProducerService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProducerService.class);

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	public void sendMessage(String message) {
		LOGGER.info(String.format("Message sent -> %s", message));
		kafkaTemplate.send(IConstant.TOPIC_NAME, message);
	}
	
//	public void sendMessageToPartition(String message) {
//		LOGGER.info(String.format("Message sent -> %s", message));
//		kafkaTemplate.sendDefault(null, message, message);
//	}
//	
//	public void sendMessageWithPartitionKey(String message) {
//		LOGGER.info(String.format("Message sent -> %s", message));
//		kafkaTemplate.sendDefault(message, message)
//	}

}
