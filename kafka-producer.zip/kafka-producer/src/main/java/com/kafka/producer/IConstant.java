package com.kafka.producer;

public interface IConstant {

	String TOPIC_NAME = "topic_test";
}
