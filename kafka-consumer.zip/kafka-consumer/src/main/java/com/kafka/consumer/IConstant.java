package com.kafka.consumer;

public interface IConstant {

	String TOPIC_NAME = "topic_test";
	String TOPIC_GROUP_ID = "topic_test_group";
}
