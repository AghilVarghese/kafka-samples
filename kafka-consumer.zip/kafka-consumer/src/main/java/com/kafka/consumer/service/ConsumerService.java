package com.kafka.consumer.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.kafka.consumer.IConstant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class ConsumerService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerService.class);

	@KafkaListener(topics = IConstant.TOPIC_NAME, groupId = IConstant.TOPIC_GROUP_ID)
	public void consume(String message) {
		LOGGER.info(String.format("Message received -> %s", message));
	}

}
